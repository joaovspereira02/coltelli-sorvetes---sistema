/* Coltelli — sistema de movimento.

   Usa o Motion (o pacote atual do Framer Motion; `motion/react` é a camada React,
   e a raiz é a API para DOM puro, que é o caso aqui — o sistema não tem build).

   Três regras que valem para tudo:
   1. Movimento serve para explicar o que mudou, nunca para enfeitar. Pedido que
      pula de coluna, item que entra na comanda, número que sobe.
   2. Nada anima na tela da cozinha a ponto de atrapalhar quem lê a 3 metros.
   3. Se a biblioteca não carregar (loja sem internet) ou a pessoa pedir menos
      movimento no sistema, tudo continua funcionando — só para de animar. */

const Anima = {
  lib: null,
  medidas: new Map(),      // chave -> DOMRect da renderização anterior
  vistos: new Set(),       // chaves que já entraram alguma vez
  ligada: true,

  /* A biblioteca é lida na hora do uso: ela pode chegar depois do primeiro render */
  motion(){
    if (this.lib) return this.lib;
    if (typeof window !== 'undefined' && window.Motion && window.Motion.animate){
      this.lib = window.Motion;
      return this.lib;
    }
    return null;
  },

  reduzido(){
    try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; }
    catch(e){ return false; }
  },

  pronta(){
    if (!this.ligada || this.reduzido() || !this.motion()) return false;
    // aba escondida não desenha: começar animação ali só deixa lixo pela frente
    return !document.hidden;
  },

  /* ---------- primitivos ---------- */

  anima(el, para, opcoes){
    const m = this.motion();
    if (!m || !el) return { finished: Promise.resolve() };
    try { return m.animate(el, para, opcoes); }
    catch(e){ return { finished: Promise.resolve() }; }
  },

  entrada(el, { atraso = 0, de = 8 } = {}){
    if (!this.pronta()) return;
    this.anima(el, { opacity: [0, 1], transform: [`translateY(${de}px)`, 'translateY(0px)'] },
      { duration: 0.28, delay: atraso, ease: [0.22, 1, 0.36, 1] });
  },

  /* Saída precisa de um fantasma: o elemento real já saiu do DOM no redesenho */
  saida(rect, html, raiz = document.body){
    if (!this.pronta() || !rect || rect.width === 0) return;
    const fantasma = document.createElement('div');
    fantasma.className = 'anima-fantasma';
    fantasma.style.cssText =
      `position:fixed;left:${rect.left}px;top:${rect.top}px;width:${rect.width}px;` +
      `height:${rect.height}px;pointer-events:none;z-index:40;`;
    fantasma.innerHTML = html;
    raiz.appendChild(fantasma);
    const a = this.anima(fantasma,
      { opacity: [1, 0], transform: ['scale(1)', 'scale(0.94)'] },
      { duration: 0.22, ease: 'easeOut' });
    (a.finished || Promise.resolve()).then(() => fantasma.remove(), () => fantasma.remove());
  },

  /* FLIP: o elemento é recriado a cada redesenho, então a gente o faz sair
     da posição antiga e caminhar até a nova. É isso que dá o pulo de coluna. */
  mover(el, antes){
    if (!this.pronta()) return;
    const agora = el.getBoundingClientRect();
    const dx = antes.left - agora.left;
    const dy = antes.top - agora.top;
    if (Math.abs(dx) < 2 && Math.abs(dy) < 2) return;
    const m = this.motion();
    const a = this.anima(el,
      { transform: [`translate(${dx}px, ${dy}px)`, 'translate(0px, 0px)'] },
      { type: m && m.spring ? 'spring' : undefined, stiffness: 420, damping: 38, mass: 0.9, duration: 0.42 });

    /* Animação interrompida no meio (aba escondida, novo redesenho) não pode
       deixar o cartão parado fora do lugar. */
    const limpar = () => { if (el.isConnected) el.style.transform = ''; };
    (a.finished || Promise.resolve()).then(limpar, limpar);
    setTimeout(limpar, 900);
  },

  /* ---------- ciclo de redesenho ---------- */

  antes(){
    this.medidas.clear();
    if (!this.pronta()) return;
    document.querySelectorAll('[data-anima]').forEach(el => {
      this.medidas.set(el.dataset.anima, {
        rect: el.getBoundingClientRect(),
        html: el.outerHTML,
      });
    });
  },

  depois(){
    if (!this.pronta()){ this.medidas.clear(); return; }
    const presentes = new Set();
    let novos = 0;

    document.querySelectorAll('[data-anima]').forEach(el => {
      const chave = el.dataset.anima;
      presentes.add(chave);
      const antes = this.medidas.get(chave);
      if (antes){
        this.mover(el, antes.rect);
      } else if (this.vistos.has(chave)){
        // existia antes, sumiu e voltou: trata como novo, sem exagero
        this.entrada(el, { de: 6 });
      } else {
        this.entrada(el, { atraso: Math.min(novos * 0.035, 0.18) });
        novos++;
      }
      this.vistos.add(chave);
    });

    // o que desapareceu sai com fantasma, na posição em que estava
    this.medidas.forEach((info, chave) => {
      if (!presentes.has(chave)){
        this.saida(info.rect, info.html);
        this.vistos.delete(chave);
      }
    });

    this.medidas.clear();
    if (this.vistos.size > 400) this.vistos.clear();
  },

  /* ---------- peças avulsas ---------- */

  /* Número que sobe. O valor anterior fica guardado por chave, porque o
     elemento é recriado a cada redesenho e perderia o ponto de partida. */
  valores: new Map(),
  formatos: {
    dinheiro: v => brl(v),
    curto: v => brlCurto(v),
    inteiro: v => String(Math.round(v)),
    minutos: v => numero(v) + ' min',
  },

  numeros(raiz = document){
    raiz.querySelectorAll('[data-num]').forEach(el => {
      const chave = el.dataset.num;
      const para = Number(el.dataset.valor || 0);
      const formata = this.formatos[el.dataset.fmt] || this.formatos.inteiro;
      const de = this.valores.has(chave) ? this.valores.get(chave) : para;
      this.valores.set(chave, para);
      if (!this.pronta() || Math.abs(para - de) < 0.005){
        el.textContent = formata(para);
        return;
      }
      const m = this.motion();
      try {
        m.animate(de, para, {
          duration: 0.5, ease: [0.22, 1, 0.36, 1],
          onUpdate: v => { el.textContent = formata(v); },
        });
      } catch(e){ el.textContent = formata(para); }
    });
  },

  /* Troca de tela: um deslize curto, só o suficiente para o olho acompanhar */
  tela(el){
    if (!this.pronta() || !el) return;
    this.anima(el, { opacity: [0, 1], transform: ['translateY(6px)', 'translateY(0px)'] },
      { duration: 0.22, ease: [0.22, 1, 0.36, 1] });
  },

  /* Modal e aviso */
  modal(caixa, fundo){
    if (!this.pronta()) return;
    this.anima(fundo, { opacity: [0, 1] }, { duration: 0.16 });
    const m = this.motion();
    this.anima(caixa, { opacity: [0, 1], transform: ['scale(0.96) translateY(10px)', 'scale(1) translateY(0px)'] },
      { type: m && m.spring ? 'spring' : undefined, stiffness: 520, damping: 34, duration: 0.3 });
  },

  aviso(el){
    if (!this.pronta()) return;
    const m = this.motion();
    this.anima(el, { opacity: [0, 1], transform: ['translateX(24px)', 'translateX(0px)'] },
      { type: m && m.spring ? 'spring' : undefined, stiffness: 480, damping: 36, duration: 0.3 });
  },

  /* Chamou a senha: o cartão pulsa uma vez, para o salão perceber */
  chamou(el){
    if (!this.pronta() || !el) return;
    this.anima(el, { transform: ['scale(1)', 'scale(1.04)', 'scale(1)'] },
      { duration: 0.5, ease: 'easeInOut' });
  },

  /* Resposta ao toque: o dedo precisa de retorno imediato no balcão */
  toque(raiz = document){
    const m = this.motion();
    if (!m || !m.press || !this.pronta()) return;
    raiz.querySelectorAll('[data-toque]:not([data-toque-ligado])').forEach(el => {
      el.dataset.toqueLigado = '1';
      try {
        m.press(el, (alvo) => {
          this.anima(alvo, { transform: 'scale(0.97)' }, { duration: 0.1 });
          return () => this.anima(alvo, { transform: 'scale(1)' }, { duration: 0.18, ease: 'easeOut' });
        });
      } catch(e){ /* sem press nesta versão: segue sem o efeito */ }
    });
  },

  /* Loja sem internet: o agente guarda uma cópia da biblioteca */
  async resgatar(){
    if (this.motion() || location.protocol !== 'http:') return;
    await new Promise((ok) => {
      const s = document.createElement('script');
      s.src = '/vendor/motion.js';
      s.onload = ok; s.onerror = ok;
      document.head.appendChild(s);
    });
    if (this.motion() && typeof App !== 'undefined') App.render();
  },
};
