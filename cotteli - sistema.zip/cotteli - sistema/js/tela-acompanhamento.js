/* Coltelli — Painel de senhas: a tela que fica virada para o salão.
   O cliente olha aqui, ou acompanha no celular pelo QR Code do cupom. */

function telaPainel(){
  const preparo = [...Dados.porStatus('novo'), ...Dados.porStatus('preparo')]
    .sort((a,b) => a.numero - b.numero);
  const prontos = Dados.porStatus('pronto').sort((a,b) => (a.prontoEm || 0) - (b.prontoEm || 0));
  const loja = Dados.loja();

  if (!preparo.length && !prontos.length){
    return `<div class="tela-centro">${vazio('sino', 'Nenhuma senha na fila',
      'As senhas aparecem aqui assim que um pedido é lançado. Deixe esta tela virada para o salão.')}</div>`;
  }

  const senha = (p, pronto) => `
    <div class="senha-cartao ${pronto ? 'pronta' : ''}" data-anima="senha-${p.id}">
      <span class="senha-num">${p.numero}</span>
      ${p.cliente && p.cliente !== 'Totem' ? `<span class="senha-cli">${esc(p.cliente)}</span>` : ''}
    </div>`;

  return `
  <div class="painel">
    <section class="painel-col">
      <header class="painel-topo">
        <span class="painel-tit">Em preparo</span>
        <span class="painel-n">${preparo.length}</span>
      </header>
      <div class="senha-grade rolagem">
        ${preparo.length ? preparo.map(p => senha(p, false)).join('')
          : '<p class="col-vazia">Nada em preparo</p>'}
      </div>
    </section>

    <section class="painel-col painel-destaque">
      <header class="painel-topo">
        <span class="painel-tit">Pode retirar</span>
        <span class="painel-n">${prontos.length}</span>
      </header>
      <div class="senha-grade rolagem">
        ${prontos.length ? prontos.map(p => senha(p, true)).join('')
          : '<p class="col-vazia">Nenhuma senha pronta</p>'}
      </div>
    </section>
  </div>
  <p class="painel-pe">${esc(loja ? loja.nome : '')}${Agente.ligado ? ' · acompanhe também pelo QR Code do seu cupom' : ''}</p>`;
}

/* Mostra ao cliente, no balcão, o QR de um pedido que já saiu */
function abrirQrPedido(codigo, numero){
  const url = Agente.urlPedido(codigo);
  Modal.abrir(`
    ${Modal.cabecalho('qr', `Pedido nº ${numero}`, url ? 'O cliente aponta a câmera' : 'Acompanhamento pelo celular')}
    ${url ? `
      <div class="qr-caixa grande">
        ${qrSvg(url, 200)}
        <span class="qr-txt">${esc(url)}</span>
      </div>`
      : `<p class="nota">${ic('info','sm')} O QR Code funciona com o agente da loja ligado — é ele que publica a
         página de acompanhamento na rede da sorveteria. Sem o agente, informe a senha <b>${numero}</b> ao cliente.</p>`}
    <div class="modal-acoes"><button class="btn btn-primario" data-act="modal-fechar">Fechar</button></div>`);
}

const acoesPainel = {
  'qr-pedido': (d) => abrirQrPedido(d.codigo, d.numero),
};
